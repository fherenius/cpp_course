#include "string.h"
#include <iostream>

using namespace std;

int main()
{
    String str(1, "abced");
    cout << str;
}