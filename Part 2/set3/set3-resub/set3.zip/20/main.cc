#include <iostream>
#include "nString.h"

int main()
{
  nString test(10, "Test times 10.\n");

  std::cout << test;
}
