#include "maxFour.ih"

size_t MaxFour::s_nMaxFour;
