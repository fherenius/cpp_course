#include "maxFour.ih"

MaxFour::~MaxFour()
{
    cout << "Destructor called\n";
}