#include <cstddef>

class MaxFour
{   
    public:
        static size_t s_nMaxFour;       // keep track of number of objects
        
        MaxFour();                      // maxFour1    
        ~MaxFour();
};