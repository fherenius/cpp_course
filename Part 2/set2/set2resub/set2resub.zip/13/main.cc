#include <iostream>
#include "maxFour/maxFour.h"

using namespace std;

int main(int argc, char const *argv[]) 
try
{
    new MaxFour[10];  // construct 10 objects
}
catch(string &e)
{
    cerr << e << '\n';
}
