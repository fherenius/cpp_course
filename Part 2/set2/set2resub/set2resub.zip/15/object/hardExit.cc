#include "object.ih"

void Object::hardExit()
{
    exit(1);
}