#include "object.ih"

void Object::throwException()
{
    throw std::string("Exception");
}