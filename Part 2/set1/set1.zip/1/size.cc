#include "numbers.ih"

size_t Numbers::size() const
{
    return d_size;
}