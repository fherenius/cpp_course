#include "storage.ih"
 
void Storage::finished()
{
  d_finished = true;
}