#include "base.ih"

void Base::vHello(std::ostream &out)
{
    out << "Hello from base\n";
}