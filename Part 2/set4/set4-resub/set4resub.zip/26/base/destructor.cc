#include "base.ih"

inline Base::~Base()
{}