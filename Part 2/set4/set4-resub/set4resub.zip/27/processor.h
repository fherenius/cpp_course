#include "msgWrapper.h"

class Processor: private MsgWrapper
{};
