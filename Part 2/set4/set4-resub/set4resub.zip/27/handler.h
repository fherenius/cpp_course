#include "msgWrapper.h"

class Handler: private MsgWrapper
{};