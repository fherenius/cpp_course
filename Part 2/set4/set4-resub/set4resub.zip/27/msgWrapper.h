#ifndef INCLUDED_MESSAGEWRAPPER_H
#define INCLUDED_MESSAGEWRAPPER_H

#include "msg.h"

class MsgWrapper
{
    public:
        Msg d_msg;
};

#endif 