#include "scanner/Scanner.h"
#include <iostream>

int main()
{
  Scanner scanner; // Init scanner

  scanner.lex();
}