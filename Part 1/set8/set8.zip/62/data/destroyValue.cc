#include "data.ih"

void Data::destroyValue()
{
	// u_value = 0;
}
