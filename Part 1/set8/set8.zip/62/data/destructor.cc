#include "data.ih"

Data::~Data()
{}
