#include "data.ih"

void Data::copyDoubleArray(Data const &other)
{
	u_double = other.u_double; 			
}
