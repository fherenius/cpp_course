#include "data.ih"

void Data::destroyDoubleArray()
{
	u_double = 0;
}
