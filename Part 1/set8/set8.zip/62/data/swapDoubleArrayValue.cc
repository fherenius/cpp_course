#include "data.ih"

void Data::swapDoubleArrayValue(Data &other)
{
	other.swapValueDoubleArray(*this);
}
