#include "data.ih"

void Data::swapDoubleArrayWord(Data &other)
{
	other.swapWordDoubleArray(*this);
}
