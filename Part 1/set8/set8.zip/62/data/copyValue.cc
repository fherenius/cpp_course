#include "data.ih"

void Data::copyValue(Data const &other)
{
	u_value = other.u_value;
}
