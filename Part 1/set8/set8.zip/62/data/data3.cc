#include "data.ih"

Data::Data(size_t value)
{
	u_value = value;
}
