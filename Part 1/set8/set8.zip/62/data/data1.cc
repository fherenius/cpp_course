#include "data.ih"

Data::Data(double (*arr)[10])
{
	u_double = arr;
}
