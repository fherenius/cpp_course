#include "data.ih"

void Data::swapWordWord(Data &other)
{
	u_word.swap(other.u_word);
}
