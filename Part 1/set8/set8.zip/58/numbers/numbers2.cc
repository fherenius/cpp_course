#include "numbers.ih"

Numbers::Numbers(size_t count)
:
    d_len(0),
    d_int(new int[count])
{}