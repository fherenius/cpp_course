#include "numbers.ih"

Numbers::Numbers()
:
    d_int(0)
{}