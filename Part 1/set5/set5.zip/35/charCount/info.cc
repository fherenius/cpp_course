#include "charCount.ih"

const CharCount::CharInfo CharCount::info()
{
    return d_charInfo;
}