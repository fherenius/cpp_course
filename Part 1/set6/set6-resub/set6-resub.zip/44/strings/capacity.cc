#include "strings.ih"

size_t Strings::capacity()
{
    return d_capacity;
}