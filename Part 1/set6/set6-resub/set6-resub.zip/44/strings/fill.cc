#include "strings.ih"

void Strings::fill(char *ntbs[])
{
    for (size_t index = 0; index != d_size; ++index)
        d_str[index] = new string(ntbs[index]); // create new pointer to string
}
