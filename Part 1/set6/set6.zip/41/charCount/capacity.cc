#include "charCount.ih"

size_t CharCount::capacity()
{
    return d_capacity;
}