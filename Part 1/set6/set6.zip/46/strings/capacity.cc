#include "strings.ih"

size_t Strings::capacity() const
{
    return d_capacity;
}