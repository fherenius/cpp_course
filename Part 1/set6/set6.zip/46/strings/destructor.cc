#include "strings.ih"
//TODO
Strings::~Strings()
{
    destroy();
}
