#include "line.ih"

string const Line::wsChars = " \f\n\r\t\v";