#include "parser.ih"

bool Parser::isIntegral() const
{
    return d_integral;
}
