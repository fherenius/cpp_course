#include "person.ih"

void Person::setName(string const &name)
{
    d_name = name;
}