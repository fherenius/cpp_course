#include "person.ih"

void Person::setMass(size_t mass)
{
    d_mass = mass;
}