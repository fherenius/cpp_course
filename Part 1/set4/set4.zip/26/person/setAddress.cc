#include "person.ih"

void Person::setAddress(string const &address)
{
    d_address = address;
}
