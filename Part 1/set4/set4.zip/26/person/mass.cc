#include "person.ih"

size_t Person::mass() const
{
    return d_mass;
}