#include "main.ih"

void usageMsg()
{
    cout << "usage: ./prog_name [requested argument (unsigned int)] [args] \n";
}