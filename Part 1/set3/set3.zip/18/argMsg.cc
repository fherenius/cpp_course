#include "main.ih"

void argMsg(size_t nr, string value)
{
    cout    << "arg number: " << nr 
            << " arg value: " << value 
            << '\n';
}