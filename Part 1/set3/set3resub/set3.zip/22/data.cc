#include "combis.ih"

size_t nTotal;
size_t nRequired;